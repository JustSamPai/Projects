<?php $__env->startSection('title', 'hero details'); ?>

<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('contracts.show', $contract->id)); ?>">
    <h1> <?php echo e($contract->name); ?> </h1>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/contracts.blade.php ENDPATH**/ ?>