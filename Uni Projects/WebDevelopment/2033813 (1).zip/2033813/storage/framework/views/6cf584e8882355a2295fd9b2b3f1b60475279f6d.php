<!-- Include Bootstrap CSS file -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h2 class="text-center mb-3">Job: <?php echo e($contract->name); ?></h2>

<div class="container mt-5">
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>Hero's:</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('heroes.show', $hero->id)); ?>"><?php echo e($hero->name); ?></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="container mt-5">
    <form id="comment-form" method="POST" action="<?php echo e(route('comments.store'), $contract->id); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="contract_id" value="<?php echo e($contract->id); ?>">
        <div class="form-group">
            <label for="content">Leave a Comment</label>
            <textarea class="form-control" name="content" id="content" rows="3"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Submit Comment</button>
    </form>
</div>

<div class="container mt-5" id="comments">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media p-3 my-3" style="background-color: #f8f9fa; border: 1px solid #ddd;">
            <div class="media-body">
                <p class="mb-1"><?php echo e($comment->content); ?></p>
                <p class="mb-1">ID: <?php echo e($comment->hero_id); ?></p>
            </div>
            <form action="<?php echo e(route('comments.delete', ['id' => $comment->id, 'contract_id' => $contract->id])); ?>" method="post">
                <?php if($comment->hero_id == $user_id || Auth::user()->role_id == 2): ?> 
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="delete-comment btn btn-danger">Delete</button>
                <a href = "<?php echo e(route('comments.edit', ['id' => $comment->id])); ?>" method = "post">Edit</a>
                <?php endif; ?>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        





</div>
<?php /**PATH /var/www/html/resources/views/layouts/contract.blade.php ENDPATH**/ ?>