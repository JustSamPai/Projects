<?php $__env->startSection('title', 'Heroes index'); ?>

<?php $__env->startSection('content'); ?>



<?php if(Auth::user()->role_id == 2): ?>
<a class="btn btn-outline-primary" href="<?php echo e(route('heroes.create')); ?>">create</a>
<?php endif; ?>

<div>
    <table>
         <tbody>
            <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <li><a href="<?php echo e(route('heroes.show', $hero)); ?>"><?php echo e($hero->name); ?></a></li>
            <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>
<div>
    <div class="flex justify-between">
            <?php echo e($heroes->appends(request()->query())->links()); ?>


      </div>
    
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hero-show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/index.blade.php ENDPATH**/ ?>