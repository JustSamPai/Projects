<?php $__env->startSection('title', 'hero details'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="/heroes">
<?php echo csrf_field(); ?>
  <label for="name">Name:</label><br>
  <input type="text" name="name" required><br>

  <label for="tier">Tier:</label><br>
  <input type="number" name="tier" step="0.1"min="0"><br>

  <label for="power">Power:</label><br>
  <input type="text" name="power"required><br>

  <label for="team_id">Team:</label><br>
  <input type="text" name="team_id"required><br>
  <p>
	<button type="submit">Create</button>
  </p>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/create.blade.php ENDPATH**/ ?>