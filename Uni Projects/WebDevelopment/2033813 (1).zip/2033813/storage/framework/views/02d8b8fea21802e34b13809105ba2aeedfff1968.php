<?php $__env->startSection('title', 'hero details'); ?>

<?php $__env->startSection('content'); ?>
<h1> USER: <?php echo e($user_id = explode('@', Auth::user()->email)[0]); ?> </h1>

<h2>Contract type <?php echo e($contract->name); ?> </h1>
<table>
    <thead>
        <tr>
            <th>Hero Name</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('heroes.show', $hero->id)); ?>"><?php echo e($hero->name); ?></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<form id="comment-form" method="POST" action="<?php echo e(route('comments.store'), $contract->id); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="contract_id" value="<?php echo e($contract->id); ?>">
    <textarea name="content" id="content"></textarea>
    <button type="submit">Submit Comment</button>
</form>
<div id="comments">
    
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment" style="padding: 20px">
    <p><?php echo e($comment->content); ?></p>

    <form action = "<?php echo e(route('comments.edit', ['id' => $comment->id])); ?>" method="post">
        
        <?php if($comment->hero_id == $user_id || Auth::user()->role_id == 2): ?> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <button type="submit">Edit</button>  
        <?php endif; ?> 

    <form action = "<?php echo e(route('comments.delete', ['id' => $comment->id, 'contract_id' => $contract->id])); ?>" method="post">
        
        <?php if($comment->hero_id == $user_id || Auth::user()->role_id == 2): ?> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete</button>  
        <?php endif; ?> 
    </form>
 
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    $(document).ready(function() {
      // When the form is submitted
      $('#comment-form').submit(function(event) {
        // Prevent the default form submission
        event.preventDefault();
  
        // Serialize the form data
        var formData = $(this).serialize();
  
        // Make an AJAX request to the server
        $.post('/comments', formData, function(data) {
          // Append the new comment to the comment list
          $('#comment-list').append(
            '<li>' + data.content + '</li>'
          );
        });
      });
    });
</script>

<style>
.delete-button {
    float: right;
}

</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/show-contracts.blade.php ENDPATH**/ ?>