<div class="space-y-5">
    <div class="border-b border-b-gray-200">
      <ul class="-mb-px flex items-center gap-4 text-sm font-medium">
        <li class="flex-1">
          <a
            href="#"
            class="relative flex items-center justify-center gap-2 px-1 py-3 text-blue-700 after:absolute after:left-0 after:bottom-0 after:h-0.5 after:w-full after:bg-blue-700 hover:text-blue-700"
          >
            Profile</a
          >
        </li>
        <li class="flex-1">
          <a href="#" class="flex items-center justify-center gap-2 px-1 py-3 text-gray-500 hover:text-blue-700">
            Preferences</a
          >
        </li>
        <li class="flex-1">
          <a href="#" class="flex items-center justify-center gap-2 px-1 py-3 text-gray-500 hover:text-blue-700">
            Notifications
            <span class="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-500"> 8 </span></a
          >
        </li>
        <li class="flex-1">
          <a href="#" class="flex items-center justify-center gap-2 px-1 py-3 text-gray-500 hover:text-blue-700">
            Applications</a
          >
        </li>
        <li class="flex-1">
          <a href="#" class="flex items-center justify-center gap-2 px-1 py-3 text-gray-500 hover:text-blue-700"
            >API</a
          >
        </li>
      </ul>
    </div><?php /**PATH /var/www/html/resources/views/layouts/test.blade.php ENDPATH**/ ?>