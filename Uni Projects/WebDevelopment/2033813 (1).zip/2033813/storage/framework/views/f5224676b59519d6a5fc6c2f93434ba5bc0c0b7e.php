<!--
  Copyright (c) [2012] [Dave Gandy]

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR

   Other head content -->
   <?php echo e($user_id = explode('@', Auth::user()->email)[0]); ?>


   <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/fontawesome.min.css" integrity="sha512-4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/solid.min.css" integrity="sha512-z3MnUZ9km7SkD3CnSY+3uw02wjKbNdR8mR5cRwlBnKA9TrNeh3jQg0Y3AWV2Zb2T7M8zN8rN7TTSNhT9e7VuA==" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
</head>
<div class="hero-details">
  <h2 class="hero-name"><?php echo e($hero->name); ?></h2>
  <table class="hero-stats">
    <tr>
      <th>
        <i class="fas fa-bolt"></i> Power
      </th>
      <td><?php echo e($hero->power); ?></td>
    </tr>
    <tr>
      <th>
        <i class="fas fa-users"></i> Team
      </th>
      <td><?php echo e($hero->team->name); ?></td>
    </tr>
    <tr>
      <th>
        <i class="fas fa-medal"></i> Tier
      </th>
      <td><?php echo e($hero->tier); ?></td>
    </tr>
  </table>
</div>
<?php if(Auth::user()->role_id == 2): ?>
<form action="<?php echo e(route('heroes.delete', ['id' => $hero->id])); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('DELETE'); ?>
  <button type="submit" class="btn btn-danger">Delete Hero</button>

</form>

<a href="<?php echo e(route('heroes.edit', ['id' => $hero->id])); ?>" class="btn btn-primary">Edit</a>
<?php endif; ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p> <?php echo e($comment->content); ?> </p>
        <?php if($comment->hero_id == $user_id || Auth::user()->role_id == 2): ?>
        <form action ="<?php echo e(route('comments.delete', ['id' => $comment->id, 'contract_id' => '-1'])); ?>" method ="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete comment</button>
        </form>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<style>
   .hero-details {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 1.5rem;
  width: 80%;
  max-width: 600px;
  margin: 3rem auto;
}

.hero-name {
  font-size: 2rem;
  margin-bottom: 1rem;
  text-transform: uppercase;
  color: #333;
}

.hero-stats {
  width: 100%;
  border-collapse: collapse;
}

</style>
  <?php /**PATH /var/www/html/resources/views/layouts/hero-details.blade.php ENDPATH**/ ?>