<?php $__env->startSection('title', 'hero details'); ?>

<?php $__env->startSection('content'); ?>


    <ul>
        
        
        
        <li>name: <?php echo e($hero ->name); ?></li>
        <li>Tier: <?php echo e($hero ->tier); ?></li>
        <li>Power: <?php echo e($hero ->power); ?></li>
        <li>Team:  <?php echo e($hero ->Team->name); ?></li>
        
    
    </ul>
    <div>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p> <?php echo e($comment->content); ?> </p>
        <form action ="<?php echo e(route('comments.delete', ['id' => $comment->id, 'contract_id' => '-1'])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete</button>
        </form>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        


    <form action = "<?php echo e(route('heroes.delete', ['id' => $hero->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete</button>
        <a href = "<?php echo e(route('heroes.edit', ['id' => $hero->id])); ?>" method = "post">Edit</a>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hero-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/show.blade.php ENDPATH**/ ?>