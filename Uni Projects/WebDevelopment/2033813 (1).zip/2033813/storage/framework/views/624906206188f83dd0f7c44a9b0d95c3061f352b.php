<?php $__env->startSection('title', 'update Hero'); ?>

<?php $__env->startSection('content'); ?>

<form method="post" action="/heroes/<?php echo e($heroes->id); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('post'); ?>

  <label for="name">Name:</label><br>
  <input type="text" name="name" value="<?php echo e($heroes['name']); ?>" required><br>

  <label for="tier">Tier:</label><br>
  <input type="number" name="tier" value="<?php echo e($heroes['tier']); ?>" step="0.01" min="0"><br>

  <label for="power">Power:</label><br>
  <input type="text" name="power" value="<?php echo e($heroes['power']); ?>" required><br>

  <p>
	<button type="submit">Update</button>
  </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/heroes/edit.blade.php ENDPATH**/ ?>