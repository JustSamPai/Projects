<?php $__env->startSection('title', 'Heroes index'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()-> role_id == 2): ?>
  <h1>Admin Only Information</h1>
  <p>This is sensitive information that should only be shown to admins.</p>
<?php else: ?>
  <h1>Regular User Information</h1>
  <p>Welcome to the site!</p>
<?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/index.blade.php ENDPATH**/ ?>