<?php $__env->startSection('title', 'update Comment'); ?>

<?php $__env->startSection('content'); ?>
<form method="post" action="/comments/<?php echo e($comments->id); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('post'); ?>

  <label for="name">Content:</label><br>
  <input type="text" name="content" value="<?php echo e($comments['content']); ?>" required><br>

  <p>
	<button type="submit">Update</button>
  </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/comment/edit.blade.php ENDPATH**/ ?>