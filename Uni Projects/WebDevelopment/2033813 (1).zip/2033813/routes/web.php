<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HeroController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\ContractController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function(){
    return view('welcome');
    
});

//Route::get('heroes', 'HeroController@index')->name('heroes.index');


Route::get('/heroes', [HeroController::class, 'index'])
    ->name('heroes.index');



Route::get('/admin', [AdminController::class, 'index'])
    ->name('admin.index');

Route::post('/heroes', [HeroController::class, 'store']);

Route::post('/heroes/{id}', [HeroController::class, 'update']);

Route::get('heroes/{id}', [HeroController::class, 'show'])
    ->name('heroes.show');

Route::get('edit/{id}', [HeroController::class, 'edit'])
    ->name('heroes.edit');

Route::post('heroes/{id}', [HeroController::class, 'update'])
    ->name('heroes.update');

Route::delete('heroes/{id}/delete', [HeroController::class, 'destroy'])
     ->name('heroes.delete');

Route::post('create/heroes', [HeroController::class, 'store'])
     ->name('heroes.store');
    
Route::get('/create', [HeroController::class, 'create'])
     ->name('heroes.create');

Route::get('/contracts', [ContractController::class, 'index'])
    ->name('contracts.index');

Route::get('/contracts/{id}', [ContractController::class, 'show'])
    ->name('contracts.show');

Route::delete('comments/delete/{id}/{contract_id}', [CommentController::class, 'destroy'])
    ->name('comments.delete');
   
Route::post('/comments', [CommentController::class, 'store'])
    ->name('comments.store');

Route::get('comment/edit/{id}', [CommentController::class, 'edit'])
    ->name('comments.edit');

Route::post('comments/{id}', [CommentController::class, 'update'])
    ->name('comment.update');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';