@extends('layouts.basic')

@section('title', 'Heroes index')

@section('content')
@if (Auth::user()-> role_id == 2)
  <h1>Admin Only Information</h1>
  <p>This is sensitive information that should only be shown to admins.</p>
@else
  <h1>Regular User Information</h1>
  <p>Welcome to the site!</p>
@endif


@endsection

