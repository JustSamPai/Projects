@extends('layouts.app')

@section('title', 'hero details')

@section('content')

<form method="POST" action="/heroes">
@csrf
  <label for="name">Name:</label><br>
  <input type="text" name="name" required><br>

  <label for="tier">Tier:</label><br>
  <input type="number" name="tier" step="0.1"min="0"><br>

  <label for="power">Power:</label><br>
  <input type="text" name="power"required><br>

  <label for="team_id">Team:</label><br>
  <input type="text" name="team_id"required><br>
  <p>
	<button type="submit">Create</button>
  </p>
</form>
@endsection
