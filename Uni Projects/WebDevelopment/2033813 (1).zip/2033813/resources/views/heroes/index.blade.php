@extends('layouts.hero-show')

@section('title', 'Heroes index')

@section('content')

{{-- {{$heroes->count()}} of {{ $heroes->total() }} --}}

@if(Auth::user()->role_id == 2)
<a class="btn btn-outline-primary" href="{{ route('heroes.create') }}">create</a>
@endif

<div>
    <table>
         <tbody>
            @foreach($heroes as $hero)
            {{-- <li><a href="{{ route('heroes.show', ['id' => $hero->id]) }}">{{ $heroes->name }}</a></li>  --}}
                <li><a href="{{ route('heroes.show', $hero)}}">{{ $hero->name}}</a></li>
            <tr>
                @endforeach
            </tr>
        </tbody>
    </table>
</div>
<div>
    <div class="flex justify-between">
            {{ $heroes->appends(request()->query())->links()}}

      </div>
    
    </div>
</div>

    {{--<p> Heroes in the city:</p>
    <ul>
        
         @foreach ($heroes as $hero)
             <li><a href="{{ route('heroes.show', ['id' => $hero->id]) }}">{{ $heroes->name }}</a></li> 
                <li><a href="{{ route('heroes.show', $hero)}}">{{ $hero->name}}</a></li>
        @endforeach 
            
     </ul>  
        <a href = "{{ route('heroes.create')}}">Create Hero</a> --}}
@endsection