@extends('layouts.app')

@section('title', 'update Hero')

@section('content')

<form method="post" action="/heroes/{{{$heroes->id}}}">
  @csrf
  @method('post')

  <label for="name">Name:</label><br>
  <input type="text" name="name" value="{{$heroes['name']}}" required><br>

  <label for="tier">Tier:</label><br>
  <input type="number" name="tier" value="{{$heroes['tier']}}" step="0.01" min="0"><br>

  <label for="power">Power:</label><br>
  <input type="text" name="power" value="{{$heroes['power']}}" required><br>

  <p>
	<button type="submit">Update</button>
  </p>
</form>
@endsection