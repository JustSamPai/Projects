@extends('layouts.contract')

@section('title', 'hero details')

@section('content')
<h1> USER: {{ $user_id = explode('@', Auth::user()->email)[0] }} </h1>

<h2>Contract type {{$contract->name}} </h1>
<table>
    <thead>
        <tr>
            <th>Hero Name</th>
        </tr>
    </thead>
    <tbody>
        @foreach($heroes as $hero)
            <tr>
                <td><a href="{{ route('heroes.show', $hero->id)}}">{{ $hero->name }}</a></td>
            </tr>
        @endforeach
    </tbody>
</table>
<form id="comment-form" method="POST" action="{{ route('comments.store'), $contract->id }}">
    @csrf
    <input type="hidden" name="contract_id" value="{{ $contract->id }}">
    <textarea name="content" id="content"></textarea>
    <button type="submit">Submit Comment</button>
</form>
<div id="comments">
    
@foreach ($comments as $comment)
    <div class="comment" style="padding: 20px">
    <p>{{ $comment->content }}</p>

    <form action = "{{ route('comments.edit', ['id' => $comment->id])}}" method="post">
        
        @if ($comment->hero_id == $user_id || Auth::user()->role_id == 2) 
        @csrf
        @method('post')
        <button type="submit">Edit</button>  
        @endif 

    <form action = "{{ route('comments.delete', ['id' => $comment->id, 'contract_id' => $contract->id])}}" method="post">
        
        @if ($comment->hero_id == $user_id || Auth::user()->role_id == 2) 
        @csrf
        @method('DELETE')
        <button type="submit">Delete</button>  
        @endif 
    </form>
 
    </div>
@endforeach
</div>

<script>
    $(document).ready(function() {
      // When the form is submitted
      $('#comment-form').submit(function(event) {
        // Prevent the default form submission
        event.preventDefault();
  
        // Serialize the form data
        var formData = $(this).serialize();
  
        // Make an AJAX request to the server
        $.post('/comments', formData, function(data) {
          // Append the new comment to the comment list
          $('#comment-list').append(
            '<li>' + data.content + '</li>'
          );
        });
      });
    });
</script>

<style>
.delete-button {
    float: right;
}

</style>


@endsection
