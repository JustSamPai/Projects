@extends('layouts.default')

@section('title', 'hero details')

@section('content')


@foreach ($contracts as $contract)
    <a href="{{ route('contracts.show', $contract->id) }}">
    <h1> {{$contract->name}} </h1>
    </a>
@endforeach


@endsection
