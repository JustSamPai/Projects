@extends('layouts.hero-details')

@section('title', 'hero details')

@section('content')


    <ul>
        
        
        {{-- <li>id: {{$id = $hero ->id}}</li> --}}
        <li>name: {{$hero ->name}}</li>
        <li>Tier: {{$hero ->tier}}</li>
        <li>Power: {{$hero ->power}}</li>
        <li>Team:  {{$hero ->Team->name}}</li>
        
    
    </ul>
    <div>
    @foreach ($comments as $comment)
        <p> {{$comment->content}} </p>
        <form action ="{{ route('comments.delete', ['id' => $comment->id, 'contract_id' => '-1'])}}">
            @csrf
            @method('DELETE')
        <button type="submit">Delete</button>
        </form>

    @endforeach
    </div>
        {{-- <li>Comments:  {{$hero ->comments->content}}</li> --}}


    <form action = "{{ route('heroes.delete', ['id' => $hero->id])}}" method="post">
        @csrf
        @method('DELETE')
        <button type="submit">Delete</button>
        <a href = "{{ route('heroes.edit', ['id' => $hero->id])}}" method = "post">Edit</a>
    </form>
    
@endsection