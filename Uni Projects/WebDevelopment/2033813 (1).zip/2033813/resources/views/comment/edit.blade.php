@extends('layouts.app')

@section('title', 'update Comment')

@section('content')
<form method="post" action="/comments/{{{$comments->id}}}">
  @csrf
  @method('post')

  <label for="name">Content:</label><br>
  <input type="text" name="content" value="{{$comments['content']}}" required><br>

  <p>
	<button type="submit">Update</button>
  </p>
</form>
@endsection