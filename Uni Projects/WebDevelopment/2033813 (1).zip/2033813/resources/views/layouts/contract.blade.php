<!-- Include Bootstrap CSS file -->
<meta name="csrf-token" content="{{ csrf_token() }}">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        @include('layouts.navigation')

<h2 class="text-center mb-3">Job: {{$contract->name}}</h2>

<div class="container mt-5">
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>Hero's:</th>
            </tr>
        </thead>
        <tbody>
            @foreach($heroes as $hero)
                <tr>
                    <td><a href="{{ route('heroes.show', $hero->id)}}">{{ $hero->name }}</a></td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="container mt-5">
    <form id="comment-form" method="POST" action="{{ route('comments.store'), $contract->id }}">
        @csrf
        <input type="hidden" name="contract_id" value="{{ $contract->id }}">
        <div class="form-group">
            <label for="content">Leave a Comment</label>
            <textarea class="form-control" name="content" id="content" rows="3"></textarea>
        </div>
        {{-- <button type="submit" class="btn btn-primary">Submit Comment</button> --}}
        <button type="submit" class="btn btn-primary">Submit Comment</button>
    </form>
</div>

<div class="container mt-5" id="comments">
    @foreach ($comments as $comment)
        <div class="media p-3 my-3" style="background-color: #f8f9fa; border: 1px solid #ddd;">
            <div class="media-body">
                <p class="mb-1">{{ $comment->content }}</p>
                <p class="mb-1">ID: {{ $comment->hero_id }}</p>
            </div>
            <form action="{{ route('comments.delete', ['id' => $comment->id, 'contract_id' => $contract->id])}}" method="post">
                @if ($comment->hero_id == $user_id || Auth::user()->role_id == 2) 
                @csrf
                @method('DELETE')
                <button type="submit" class="delete-comment btn btn-danger">Delete</button>
                <a href = "{{ route('comments.edit', ['id' => $comment->id])}}" method = "post">Edit</a>
                @endif
            </form>
        </div>
    @endforeach
</div>
        {{-- <script src="https://code.jquery.com/jquery-3.6.3.min.js" type="text/javascript"></script>
        <script src="https://code.jquery.com/jquery-3.6.3.min.js" type="text/javascript"></script>
        <script src="https://cdn.jsdelivr.net/npm/owl.carousel@2.3.4/dist/owl.carousel.min.js" type="text/javascript"></script>
        <script>
            $('.category-carousel').owlCarousel({
                loop:true,
                margin:10,
                nav:true,
                dots:false,
                responsive:{
                    0:{
                        items:2
                    },
                    600:{
                        items:3
                    },
                    1000:{
                        items:4
                    }
                }
            }) --}}
{{-- //         </script>
//         <script> --}}
{{-- //             $.ajaxSetup({
//         headers: {
//             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//         }
//     });
//     $('.delete-comment').on('click', function(e) {
//         e.preventDefault();
//         var id = $(this).val();
//         var form = $(this).parents('form');
//         var url = form.attr('action');
//         $.ajax({
//             type: "DELETE",
//             url: url,
//             data: {
//                 "id": id,
//             },
//             success: function(data) {
//                 form.remove();
//             },
//             error: function(data) {
//                 console.log(data);
//             }
//         });
//     });
// </script> --}}
{{-- //     $(document).ready(function() {
//     $(document).on('click', '.delete-comment', function(e) {
//       e.preventDefault(); // prevent the form from submitting
//       if (confirm("Are you sure you want to delete this comment?")) {
//         var commentId = $(this).val(); // get the comment id from the delete button's value attribute
//         var formData = { 'comment_id': commentId }; // create an object with the form data
//         console.log(commentId);
//         $.ajax({
//           type: 'POST',
//           url: '/comments/delete', // your delete route
//           data: $(commentId).serialize(), // pass the form data object as the request body
//           success: function(response) {
//             if (response.status == 200) {
//               // remove the comment element from the page
//               $('.delete-comment[value="' + commentId + '"]').closest('.media-body').remove();
//               alert(response.message);
//             } else {
//               alert(response.message);
//             }
//           }
//         });
//       }
//     });
//   });
  </script> --}}


</div>
