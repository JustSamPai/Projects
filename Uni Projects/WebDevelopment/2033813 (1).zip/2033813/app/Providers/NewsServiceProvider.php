<?php

namespace App\Providers;
use GuzzleHttp\Client;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\App;

class NewsServiceProvider extends ServiceProvider
{
    private $client;
    public function register()
    {
        $this->app->bind(Client::class, function () {
            return new Client();
        });
        $this->app->singleton('articles', function () {
            return $this->getArticles();
        });
    }

    public function getArticles()
    {
        $client = $this->app->make(Client::class);
        $response = $client->get('https://newsapi.org/v2/top-headlines?country=us&apiKey=cd763113bd24426ebef504500ba9f18c');
        //dd(((json_decode($response->getBody(), true)['articles'])));
       // return json_decode($response->getBody(), true);
        return (json_decode($response->getBody(), true)['articles']);
        
    }
}
