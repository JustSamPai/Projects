<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Contract;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // $comments = Comment::all();
        // return view('heroes.contracts', compact('comment'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
        $email_id = explode('@', Auth::user()->email)[0];
        $request->validate([
            'contract_id' => 'required',
            'content' => 'required | max:1000',
        ]);
        
        $newComment = new Comment;
        $newComment->contract_id = $request->contract_id;
        $newComment->content = $request->content;
        $newComment->hero_id = $email_id;
        $newComment->save(); 
        $contract_id = $newComment->contract_id;
        return redirect('/contracts/' .$contract_id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $comments = Comment::find($id);
        return view('comment.edit', ['comments'=>$comments]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'content' => 'required',
        ]);
        dd($request);
    
        // Find the hero in the database and update its attributes
        $comments = Comment::find($id);
        $comments->content=$request->content;
        
        $heroes->save();
        // Redirect the user to the show page for the updated hero
        // return redirect()->route('heroes.show', ['heroes'=>$heroes]);
        return redirect('/comments/edit/' .$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function destroy(Request $request){
    //     console.log('hi');
    //     if (Auth::check()) {
    //         $comment = Comment::where('id', $request->id);
    //         $comment = $comment->where('hero_id', explode('@', Auth::user()->email)[0]);
    //         $comment->delete();
    //         return response()->json([
    //             'status' => 200,
    //             'message' =>'Comment Deleted Successfully'
    //         ]);
    //     } else {
    //         return response()->json([
    //             'status' => 401,
    //             'message' =>'Not Authorised'
    //         ]);
    //     }

    // }
    public function destroy($id, $contract_id)
    {
        //
        
        if($contract_id != -1){
            $comment = Comment::find($id);
            $comment -> delete();
            return redirect('/contracts/'.$contract_id);
        } else {
            $comment = Comment::find($id);
            $comment -> delete();
            return redirect('/heroes/'.$comment->comment_id);
        }

    }
}
