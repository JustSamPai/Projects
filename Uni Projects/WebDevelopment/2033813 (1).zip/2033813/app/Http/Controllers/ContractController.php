<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Contract;
use App\Models\Hero;

class ContractController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $articles = app('articles');
        $contracts = Contract::all();
        // return view('heroes.contracts', compact('contracts'));
        return view('heroes.contracts', ['contracts' => $contracts, 'articles' => $articles]); 

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($contract)
    {
        //
        $userID = explode('@', Auth::user()->email)[0];
        
        $contracts = Contract::find($contract);
        $articles = app('articles');
        
        //$contract = Hero::where('id', $contract)
        //    ->get();
        //    dd($contract);
        //$heroes = $contract->heroes()->get();
        $heroes = $contracts->heroes;
        
        
        //$test = $heroes->contains('id', $userID);
       //dd($heroes);
        if ($heroes->contains('id', $userID) || Auth::user()->role_id == 2) {
            
            $comments = Comment::all()->where('contract_id', $contract);
            return view('heroes.show-contracts')->with(['heroes' => $heroes, 'contract' => $contracts, 'comments' => $comments, 'articles' => $articles]);
        } else {
            return redirect('/contracts')->with('error', 'You do not have access to this page');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
