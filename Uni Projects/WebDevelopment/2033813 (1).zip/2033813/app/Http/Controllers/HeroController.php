<?php
namespace App\Models;
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Models\Hero;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Team;
use Illuminate\Support\Facades\Auth;
use App\Models\Contract;
class HeroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $articles = app('articles');
        $heroes = Hero::all();
        $heroes = Hero::paginate(10);
        $perPage = (int)$request->query('per_page');
        $heroes = Hero::orderBy('id', 'asc')->paginate($perPage);
    //return view('admin.posts.index', ['posts' => $posts]);
        return view('heroes.index', ['heroes' => $heroes, 'articles' => $articles]); 
        //return view('heroes.index', compact('heroes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $heroes = Hero::all();
        return view('heroes.create', $heroes);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the request data
        $articles = app('articles')[0];

        $request->validate([
            'name' => 'required',
            'tier' => 'required|numeric',
            'power' => 'required',
            'team_id' => 'required',
        ]);

        // Create a new Hero model instance
        $hero = new Hero();

        // Assign the form input values to the model properties
        $hero->name = $request->name;
        $hero->tier = $request->tier;
        $hero->power = $request->power;
        $hero->team_id = $request->team_id;

        // Save the model to the database
        //dd($hero);
        $hero->save();

        // Redirect the user to the show page for the new hero
        //return redirect()->route('heroes.show', ['hero' => $hero]);
        return redirect('/heroes');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $user_id = explode('@', Auth::user()->email)[0];
        $hero = Hero::find($id);
        $comments = Comment::where('hero_id', $id)->get();

        $teams = Team::find($hero->team_id);
        //return view('heroes.show', compact('hero'));
        
        return view('heroes.show')->with(['hero' => $hero, 'teams' => $teams, 'comments' => $comments]);

        //return view('hero.show', ['hero'=>$hero]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $heroes = Hero::find($id);
        return view('heroes.edit', ['heroes'=>$heroes]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $request->validate([
        'name' => 'required',
        'tier' => 'required|numeric',
        'power' => 'required',
    ]);

    // Find the hero in the database and update its attributes
    $heroes = Hero::find($id);
    $heroes->name=$request->name;
    $heroes->tier=$request->tier;
    $heroes->power=$request->power;
    $heroes->save();
    // Redirect the user to the show page for the updated hero
    // return redirect()->route('heroes.show', ['heroes'=>$heroes]);
    return redirect('/heroes/' .$id);

    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $hero = Hero::find($id);
        $hero->delete();
        return redirect('/heroes');
    }
}
