<?php

namespace App\Http\middleware;

use Closure;
use Illuminate\Http\Request;

class Admin
{
    public function handle(Request $request, Closure $next){
        if (!auth()->check() || !auth()->user()->role_id == 2){
            abort(403);
        }
        return $next($request);
    }
}