<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hero extends Model
{
    public $timestamps = false;
    use HasFactory;

    //creates a 1 to many relationship with "team"
    public function team()
    {
        return $this ->belongsTo('App\Models\Team');
    }
    

    /*
    creates a many to many 
    relationship with "contrats"
    */
    public function contracts()
    {
        return $this->hasMany('App\Models\Contract');
    }
    //protected $attributes = ['finished' = false]
}
