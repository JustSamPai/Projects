<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    public $timestamps = false;
    use HasFactory;

    //creates a 1 to many relationship with hero
    public function heroes()
    {
        return $this->hasMany('App\Models\Hero');
    }
}
