<?php

namespace Database\Seeders;

use App\Models\Hero;
use App\Models\Contract;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ContractTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($i =0; $i < 10; $i++)
        {
            Contract::factory()->count(1)
            ->hasAttached(Hero::get()->random($i))
            ->create();
        } 

    }
}
