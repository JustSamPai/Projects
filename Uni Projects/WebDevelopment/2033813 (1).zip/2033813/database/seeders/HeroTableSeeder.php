<?php

namespace Database\Seeders;

use App\Models\Hero;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HeroTableSeeder extends Seeder
{
    /**
     * Run the Hero database seeds.
     *
     * @return void
     */
    public function run()
    {
        //create one hardcoded hero
        
        $a = new Hero;
        $a->name = 'Bruce Wane';
        $a->tier = 2.0;
        $a->power = 'money';
        $a->team_id = 1;
        $a->save();

        Hero::factory()->count(100)->create();
    }
}
