<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Team>
 */
class TeamFactory extends Factory
{
    /**
     * factory for Hero teams.
     * 
     * @return array<string, mixed>
     */

    public function definition()
    {
        return [
            'name'=> fake()->unique()->randomElement(['void','holy','banana']),            
        ];
    }
}
