<?php

namespace Database\Factories; 


use App\Models\Team;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Hero>
 */
class HeroFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    
    public function definition()
    {
        
        return [
            'name' => fake()->name(),
            'tier' => fake()->randomFloat(2,0,10),
            'power'=> fake() -> randomElement(['fire','water','earth','air',
            'wood','light','dark','money']),
            'team_id'=>Team::inRandomOrder()->first()->id,
        ];
    }
}
