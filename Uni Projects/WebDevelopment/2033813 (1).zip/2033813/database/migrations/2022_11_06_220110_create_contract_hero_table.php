<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations for pivot table.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contract_hero', function (Blueprint $table) {
            $table->primary(['contract_id', 'hero_id']);
            $table->unsignedBigInteger('contract_id');
            $table->unsignedBigInteger('hero_id');
            $table->timestamps();

            $table->foreign('contract_id')->references('id')->
                    on('contracts')->onDelete('cascade')->onUpdate('cascade');

            $table->foreign('hero_id')->references('id')->
                    on('heroes')->onDelete('cascade')->onUpdate('cascade');        
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contract_hero');
    }
};
